package main.master.machinetest.ui.football

import android.graphics.Color
import androidx.lifecycle.ViewModelProviders
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import kotlinx.android.synthetic.main.football_fragment.*

import main.master.machinetest.R
import main.master.machinetest.data.model.Football
import main.master.machinetest.data.model.Team
import main.master.machinetest.data.network.FootballApi
import main.master.machinetest.data.repository.FootballRepository

class FootballFragment :  Fragment(), RecyclerViewClickListener{

    private lateinit var factory: FootballViewModelFactory
    private lateinit var viewModel: FootballViewModel
 //   private lateinit var swipeToRefresh: SwipeRefreshLayout

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.football_fragment, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        val api = FootballApi()
        val repository = FootballRepository(api)

        factory = FootballViewModelFactory(repository)
        viewModel = ViewModelProviders.of(this, factory).get(FootballViewModel::class.java)

        viewModel.getFootball()

        viewModel.football.observe(viewLifecycleOwner, Observer { football ->
            recycler_view_football.also {
                it.layoutManager = LinearLayoutManager(requireContext())
                it.setHasFixedSize(true)
                it.adapter = FootballAdapter(football.api.teams, this)
            }
        })


      fetchUsersByPullToRefresh()


        }


    private fun fetchUsersByPullToRefresh() {


        //** Set the colors of the Pull To Refresh View
      /*  swipeToRefresh.setProgressBackgroundColorSchemeColor(ContextCompat.getColor(context.getA, R.color.colorPrimary))
        swipeToRefresh.setColorSchemeColors(Color.WHITE)*/

        swipeToRefresh?.setOnRefreshListener {
            viewModel.getFootball()

            swipeToRefresh.isRefreshing = true
            viewModel.football.observe(viewLifecycleOwner, Observer { football ->
                recycler_view_football.also {
                    it.layoutManager = LinearLayoutManager(requireContext())
                    it.setHasFixedSize(true)
                    it.adapter = FootballAdapter(football.api.teams, this)
                }
            })
            swipeToRefresh.isRefreshing  = false

        }

    }


    override fun onRecyclerViewItemClick(view: View, team: Team) {
        when(view.id){
            R.id.button_book -> {
                Toast.makeText(requireContext(), "Book Button Clicked",Toast.LENGTH_LONG).show()
            }
            R.id.layout_like ->{
                Toast.makeText(requireContext(), "Like Layout Clicked",Toast.LENGTH_LONG).show()
            }
        }
    }

}
