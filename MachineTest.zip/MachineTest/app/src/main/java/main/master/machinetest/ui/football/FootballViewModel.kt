package main.master.machinetest.ui.football

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel;
import kotlinx.coroutines.Job
import main.master.machinetest.data.model.Football
import main.master.machinetest.data.repository.FootballRepository
import main.master.machinetest.util.Coroutines

class FootballViewModel(
    private val repository: FootballRepository
) : ViewModel() {

    private lateinit var job: Job

    private val _football = MutableLiveData<Football>()
    val foottest:List<Football>
        get() = _football

    val foottest:List<Football>

     fun getFootball() {
        job = Coroutines.ioThenMain(
            { repository.getFootball() },
            { _football.value = it }
        )
        repository.saveUser(football)
    }

    override fun onCleared() {
        super.onCleared()
        if(::job.isInitialized) job.cancel()
    }
}
