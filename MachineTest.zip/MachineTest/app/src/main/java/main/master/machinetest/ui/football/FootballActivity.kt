package main.master.machinetest.ui.football

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import main.master.machinetest.R

class FootballActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_football)
    }
}
