package main.master.machinetest.data.model


import com.google.gson.annotations.SerializedName

data class Football(
    @SerializedName("api")
    val api: Api
)