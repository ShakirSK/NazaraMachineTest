package main.master.machinetest.ui.football


import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import main.master.machinetest.R
import main.master.machinetest.data.model.Football
import main.master.machinetest.data.model.Team
import main.master.machinetest.databinding.RecyclerviewFootballBinding

class FootballAdapter (
    private val team:  List<Team>,
    private val listener: RecyclerViewClickListener
) : RecyclerView.Adapter<FootballAdapter.MoviesViewHolder>(){

    override fun getItemCount() = team.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        MoviesViewHolder(
            DataBindingUtil.inflate(
                LayoutInflater.from(parent.context),
                R.layout.recyclerview_football,
                parent,
                false
            )
        )

    override fun onBindViewHolder(holder: MoviesViewHolder, position: Int) {
        Log.d("sizearray", team.size.toString());
        holder.recyclerviewMovieBinding.viewmodel = team[position]
        holder.recyclerviewMovieBinding.buttonBook.setOnClickListener {
            listener.onRecyclerViewItemClick(holder.recyclerviewMovieBinding.buttonBook, team[position])
        }
        holder.recyclerviewMovieBinding.layoutLike.setOnClickListener {
            listener.onRecyclerViewItemClick(holder.recyclerviewMovieBinding.layoutLike, team[position])
        }
    }


    inner class MoviesViewHolder(
        val recyclerviewMovieBinding: RecyclerviewFootballBinding
    ) : RecyclerView.ViewHolder(recyclerviewMovieBinding.root)

}